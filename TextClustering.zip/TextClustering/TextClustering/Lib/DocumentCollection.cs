﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TextClustering.Lib
{
    /// <summary>
    /// It represents the collection of document or corpus
    /// </summary>
     class DocumentCollection
    {
        public  List<String> DocumentList { get; set; }
    }
}
