using System;
using System.Collections.Generic;
using System.Linq;

namespace TextClustering.Lib
{
    public class Centroid
    {
        public List<DocumentVector> GroupedDocument { get; set; }
    }
}
